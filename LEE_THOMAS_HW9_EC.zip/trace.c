#include <stdio.h>
#include "ObjectFiles.h"

int main(int argc, char *argv[]) {
	MachineState machine;

	// start from obj arguments
	int i = 2;
	
	// need at least two arguments
	if (argc < 2) {
		printf ("ERROR: Not enough arguments");
		return 1;
	}
	// go through each obj name
	while (i < argc) {
		if (ReadObjectFile(argv[i], &machine) == 1) {
			printf ("ERROR: Invalid file");
			return 1;
		}
		i++;
	}
	// print every memory value
	printf ("Begin trace");
	i = 0;
	while (i < 65536) {
		printf("%x\n", machine.memory[i]);
		i++;
	}
	return 0;
}